import { Node, Flow } from "pocketflow";

/*
 * Nodo único:
 * 1. Leer shared.graph (string)
 * 2. Parsear el grafo
 * 3. Calcular el grado de cada nodo
 * 4. Guardar shared.result
 */

class GraphDegreeNode extends Node {

  prep(shared) {
    return shared.graph;
  }

  exec(graphText) {
    if (typeof graphText !== "string") {
      throw new Error("El grafo debe ser un String");
    }

    const degree = {};
    const nodes = graphText.split(";");

    for (const node of nodes) {
      if (!node) continue;

      const [vertex, neighbors] = node.split(":");

      // Inicializar grado
      degree[vertex] = neighbors ? neighbors.length : 0;
    }

    return degree;
  }

  post(shared, prepRes, execRes) {
    shared.result = execRes;
    return null; // Fin del flujo
  }
}

export function buildGraphDegreeFlow() {
  return new Flow(new GraphDegreeNode());
}

/*
### RESUMEN ###
1. shared.graph contiene el grafo como texto
2. prep toma la entrada
3. exec parsea y calcula grados
4. post guarda el resultado
*/
