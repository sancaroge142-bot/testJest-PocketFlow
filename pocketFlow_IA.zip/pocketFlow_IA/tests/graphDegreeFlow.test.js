import { buildGraphDegreeFlow } from "../src/graphDegreeFlow";

describe("GraphDegreeFlow (PocketFlow)", () => {

  test("Grafo con múltiples nodos", async () => {
    const flow = buildGraphDegreeFlow();
    const shared = {
      graph: "A:BCD;B:;C:D;D:BC"
    };

    await flow.run(shared);

    expect(shared.result).toEqual({
      A: 3,
      B: 0,
      C: 1,
      D: 2
    });
  });

  test("Grafo con un solo nodo sin aristas", async () => {
    const flow = buildGraphDegreeFlow();
    const shared = {
      graph: "A:"
    };

    await flow.run(shared);

    expect(shared.result).toEqual({
      A: 0
    });
  });

  test("Grafo vacío", async () => {
    const flow = buildGraphDegreeFlow();
    const shared = {
      graph: ""
    };

    await flow.run(shared);

    expect(shared.result).toEqual({});
  });

});

/*
### RESUMEN ###
1. Cada test prueba un tipo de grafo
2. Se valida el cálculo del grado
3. Se cubren casos normales y bordes
*/
